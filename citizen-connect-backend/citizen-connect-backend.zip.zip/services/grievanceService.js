'use strict';

// Load env vars (local only)
require('dotenv').config();

// AWS SDK
const AWS = require('aws-sdk');

// Configure AWS region
AWS.config.update({
  region: process.env.AWS_REGION
});

// Create DynamoDB Document Client
const dynamoDB = new AWS.DynamoDB.DocumentClient();

// Table name (used later)
const TABLE_NAME = process.env.TABLE_NAME;

// ---- PLACEHOLDER SERVICE FUNCTIONS ---- //

const { v4: uuidv4 } = require('uuid');

// CREATE grievance
const createGrievance = async (data) => {
  const grievanceId = `grv_${uuidv4()}`;
  const timestamp = new Date().toISOString();

  const params = {
    TableName: TABLE_NAME,
    Item: {
      grievanceId,
      citizenName: data.citizenName,
      citizenEmail: data.citizenEmail,
      category: data.category,
      description: data.description,
      status: 'PENDING',
      createdAt: timestamp,
      updatedAt: timestamp,
      adminRemarks: ''
    }
  };

  await dynamoDB.put(params).promise();

  return {
    message: 'Grievance created successfully',
    grievanceId
  };
};


const getGrievances = async () => {
  return {
    message: 'DynamoDB client configured (read)'
  };
};

const updateGrievance = async () => {
  return {
    message: 'DynamoDB client configured (update)'
  };
};

const deleteGrievance = async () => {
  return {
    message: 'DynamoDB client configured (delete)'
  };
};

module.exports = {
  createGrievance,
  getGrievances,
  updateGrievance,
  deleteGrievance
};
